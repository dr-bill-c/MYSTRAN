The DAT and F06 files in these subfolders comprise most of the
test problems used to verify the veracity of new versions prior to 
their release. Most of these example problems were developed to
demonstrate (and check out) various features in MYSTRAN. They are
generally small problems which, in many cases, have been solved by
hand to verify the MYSTRAN results.