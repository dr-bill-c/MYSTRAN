package Win32::ChangeNotification;
require Win32::ChangeNotify;
*Win32::ChangeNotification::=\\%Win32::ChangeNotify::;
# provided for backward compatibility
1;
__END__
